alert("正在为您注入，请稍等...");
setTimeout(function(){
    document.getElementById('add').innerHTML = '<tr><td><input name="tr1" type="text" maxlength="81" class="input1"></td><td><input name="tr2" type="text" maxlength="80" class="input1"></td><td><input name="tr3" type="text" maxlength="80" class="input1"></td><td><input name="tr4" type="text" maxlength="80" class="input1"></td><td><input name="tr5" type="text" maxlength="80" class="input1"></td><td><input name="tr6" type="text" maxlength="80" class="input1"></td></tr><tr><td><input name="tr1" type="text" maxlength="80" class="input1"></td><td><input name="tr2" type="text" maxlength="80" class="input1"></td><td><input name="tr3" type="text" maxlength="80" class="input1"></td><td><input name="tr4" type="text" maxlength="80" class="input1"></td><td><input name="tr5" type="text" maxlength="80" class="input1"></td><td><input name="tr6" type="text" maxlength="80" class="input1"></td></tr>';
    alert("完毕...");
}, 3000);
